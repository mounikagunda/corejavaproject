import java.util.*;

public class Cricket
{
	public static void main(String[] args)
	{
		int o1,o2,score1,score2,rr1,rr2;
	
		Scanner s=new Scanner(System.in);
		System.out.println("welcome to the one day international 50 overs match");
        Sytem.out.println("enter the first team name");
        te1=s.next();
        
        System.out.println("enter the second team name");
        te2=s.next();
        System.out.println("match starts b/w india v/s australia");
        
       
        int overs1() throws Exception
        {
        	 
        	System.out.println("enter the overs played by team:"+te1);
            o1=s.nextInt();
            if(o1>50)
        	{
        		throw new OversException();
        	}
        	return o1;
        }
        int calculatingScore1()
        {
        System.out.println("Enter the Runrate for :"+te1);
        float rr1=s.nextFloat();
        int score1=rr*o1;
        return score1;
        }
        int overs2() throws Exception
        {
        	 
        	System.out.println("enter the overs played by team:"+te2);
            o2=s.nextInt();
            if(o2>50)
        	{
        		throw new OversException();
        	}
        	return o2;
        }
        int calculatingScore2()
        {
        System.out.println("Enter the Runrate for :"+te2);
        float rr2=s.nextFloat();
        int score2=rr*o2;
        return score2;
        }
	}
}